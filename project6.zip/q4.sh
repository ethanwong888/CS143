zcat /home/cs143/data/googlebooks-eng-all-1gram-20120701-s.gz | datamash --sort --full groupby 2 max 3 | awk '$2 > 1899' | cut -f 1,2,3
