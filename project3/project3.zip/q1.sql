SELECT id 
FROM Laureate 
WHERE fname = "Marie" and familyName = "Curie";