SELECT familyName 
FROM Laureate 
GROUP BY COALESCE(familyName, id) 
HAVING COUNT(*) >= 5;